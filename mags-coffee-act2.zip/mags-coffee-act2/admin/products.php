<?php
require '../config.php';
require_role(['admin', 'staff'], '../');
require 'functions.php';

// DELETE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash('Invalid request.', 'error');
    } elseif (($_POST['action'] ?? '') === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $s = $pdo->prepare('SELECT image_url FROM products WHERE id = ?');
        $s->execute([$id]);
        $p = $s->fetch();
        if ($p) {
            $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
            delete_image($p['image_url']);
            flash('Product binura.');
        } else {
            flash('Hindi nahanap ang product.', 'error');
        }
    }
    redirect('products.php');
}

// READ (with search + category filter)
$q   = trim($_GET['q'] ?? '');
$cat = trim($_GET['cat'] ?? '');
$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(name LIKE ? OR description LIKE ?)';
    $params[] = "%$q%";
    $params[] = "%$q%";
}
if ($cat !== '') {
    $where[] = 'category = ?';
    $params[] = $cat;
}
$sql = 'SELECT * FROM products' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
$categories = $pdo->query('SELECT DISTINCT category FROM products ORDER BY category')->fetchAll(PDO::FETCH_COLUMN);

$base = '../';
$pageTitle = 'Admin - Products';
require '../header.php';
?>
<h1>Products</h1>
<?php require '_nav.php'; ?>

<div class="row toolbar">
    <form method="get" class="row">
        <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search name / description" class="search">
        <select name="cat" class="auto">
            <option value="">All categories</option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= e($c) ?>" <?= $cat === $c ? 'selected' : '' ?>><?= e($c) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="secondary">Filter</button>
    </form>
    <a class="btn" href="product_form.php">+ Add product</a>
</div>

<table>
    <tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr>
    <?php foreach ($products as $p): ?>
    <tr>
        <td>
            <?php if ($p['image_url']): ?>
                <img class="thumb" src="../<?= e($p['image_url']) ?>" alt="">
            <?php endif; ?>
        </td>
        <td><?= e($p['name']) ?></td>
        <td><?= e($p['category']) ?></td>
        <td><?= money((float)$p['price']) ?></td>
        <td><?= (int)$p['stock'] ?><?= $p['stock'] <= 5 ? ' <span class="badge warn">low</span>' : '' ?></td>
        <td class="actions">
            <a class="btn small" href="product_form.php?id=<?= (int)$p['id'] ?>">Edit</a>
            <form method="post" onsubmit="return confirm('Burahin ang <?= e(addslashes($p['name'])) ?>?')">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <button type="submit" class="small danger">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$products): ?><tr><td colspan="6">Walang nahanap na product.</td></tr><?php endif; ?>
</table>
<?php require '../footer.php'; ?>
