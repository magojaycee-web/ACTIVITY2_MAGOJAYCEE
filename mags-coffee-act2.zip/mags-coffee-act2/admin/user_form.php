<?php
require '../config.php';
require_role(['admin'], '../');   // User Management = admin only

$id = (int)($_GET['id'] ?? 0);

if ($id === (int)$_SESSION['user_id']) {
    flash('Gamitin ang Profile page para sa sarili mong account.', 'error');
    redirect('../profile.php');
}

$user = null;
if ($id) {
    $s = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $s->execute([$id]);
    $user = $s->fetch();
    if (!$user) {
        flash('Hindi nahanap ang user.', 'error');
        redirect('users.php');
    }
}

$errors = [];
$f = [
    'username'  => $user['username'] ?? '',
    'full_name' => $user['full_name'] ?? '',
    'email'     => $user['email'] ?? '',
    'role'      => $user['role'] ?? 'customer',
    'status'    => $user['status'] ?? 'active',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f['username']  = trim($_POST['username'] ?? '');
    $f['full_name'] = trim($_POST['full_name'] ?? '');
    $f['email']     = trim($_POST['email'] ?? '');
    $f['role']      = $_POST['role'] ?? '';
    $f['status']    = $_POST['status'] ?? '';
    $password       = $_POST['password'] ?? '';

    if (!csrf_check()) $errors[] = 'Invalid request.';
    if (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $f['username'])) $errors[] = 'Username: 3-30 characters (letters, numbers, underscore).';
    if ($f['full_name'] === '' || strlen($f['full_name']) > 100) $errors[] = 'Ilagay ang buong pangalan.';
    if (!filter_var($f['email'], FILTER_VALIDATE_EMAIL) || strlen($f['email']) > 100) $errors[] = 'Maling email.';
    if (!in_array($f['role'], ROLES, true)) $errors[] = 'Maling role.';
    if (!in_array($f['status'], STATUSES, true)) $errors[] = 'Maling status.';
    if (!$user && strlen($password) < 8) $errors[] = 'Password: hindi bababa sa 8 characters.';
    if ($user && $password !== '' && strlen($password) < 8) $errors[] = 'Bagong password: hindi bababa sa 8 characters.';

    if (!$errors) {
        $c = $pdo->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id <> ?');
        $c->execute([$f['username'], $f['email'], $user['id'] ?? 0]);
        if ($c->fetch()) $errors[] = 'Gamit na ng ibang user ang username o email.';
    }

    if (!$errors) {
        if ($user) {
            if ($password !== '') {
                $pdo->prepare('UPDATE users SET username=?, full_name=?, email=?, role=?, status=?, password_hash=? WHERE id=?')
                    ->execute([$f['username'], $f['full_name'], $f['email'], $f['role'], $f['status'], password_hash($password, PASSWORD_DEFAULT), $user['id']]);
            } else {
                $pdo->prepare('UPDATE users SET username=?, full_name=?, email=?, role=?, status=? WHERE id=?')
                    ->execute([$f['username'], $f['full_name'], $f['email'], $f['role'], $f['status'], $user['id']]);
            }
            flash('Na-update ang user.');
        } else {
            $pdo->prepare('INSERT INTO users (username, full_name, email, password_hash, role, status) VALUES (?,?,?,?,?,?)')
                ->execute([$f['username'], $f['full_name'], $f['email'], password_hash($password, PASSWORD_DEFAULT), $f['role'], $f['status']]);
            flash('Naidagdag ang user.');
        }
        redirect('users.php');
    }
}

$base = '../';
$pageTitle = $user ? 'Edit user' : 'Add user';
require '../header.php';
?>
<h1><?= $user ? 'Edit user' : 'Add user' ?></h1>
<?php require '_nav.php'; ?>

<?php foreach ($errors as $err): ?><p class="error"><?= e($err) ?></p><?php endforeach; ?>

<div class="box">
<form method="post" class="stack">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <label>Username <input type="text" name="username" value="<?= e($f['username']) ?>" maxlength="30" required></label>
    <label>Buong pangalan <input type="text" name="full_name" value="<?= e($f['full_name']) ?>" maxlength="100" required></label>
    <label>Email <input type="email" name="email" value="<?= e($f['email']) ?>" maxlength="100" required></label>
    <label>Role
        <select name="role">
            <?php foreach (ROLES as $r): ?>
                <option value="<?= $r ?>" <?= $f['role'] === $r ? 'selected' : '' ?>><?= $r ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Status
        <select name="status">
            <?php foreach (STATUSES as $st): ?>
                <option value="<?= $st ?>" <?= $f['status'] === $st ? 'selected' : '' ?>><?= $st ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label><?= $user ? 'Reset password (iwanang blangko kung hindi papalitan)' : 'Password' ?>
        <input type="password" name="password" autocomplete="new-password" <?= $user ? '' : 'required' ?>>
    </label>
    <div class="row">
        <button type="submit"><?= $user ? 'Save changes' : 'Add user' ?></button>
        <a class="btn secondary" href="users.php">Cancel</a>
    </div>
</form>
</div>
<?php require '../footer.php'; ?>
