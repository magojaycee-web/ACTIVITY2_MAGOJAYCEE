<?php $here = basename($_SERVER['SCRIPT_NAME']); ?>
<div class="subnav">
    <a href="index.php" class="<?= $here === 'index.php' ? 'active' : '' ?>">Dashboard</a>
    <a href="products.php" class="<?= in_array($here, ['products.php', 'product_form.php'], true) ? 'active' : '' ?>">Products</a>
    <a href="orders.php" class="<?= $here === 'orders.php' ? 'active' : '' ?>">Orders</a>
    <?php if (is_admin()): ?>
        <a href="users.php" class="<?= in_array($here, ['users.php', 'user_form.php'], true) ? 'active' : '' ?>">Users</a>
    <?php endif; ?>
</div>
