<?php
require '../config.php';
require_role(['admin', 'staff'], '../');
require 'functions.php';

$id = (int)($_GET['id'] ?? 0);
$product = null;
if ($id) {
    $s = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $s->execute([$id]);
    $product = $s->fetch();
    if (!$product) {
        flash('Hindi nahanap ang product.', 'error');
        redirect('products.php');
    }
}

$errors = [];
$f = [
    'name'        => $product['name'] ?? '',
    'category'    => $product['category'] ?? '',
    'description' => $product['description'] ?? '',
    'price'       => $product['price'] ?? '',
    'stock'       => $product['stock'] ?? 0,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f['name']        = trim($_POST['name'] ?? '');
    $f['category']    = trim($_POST['category'] ?? '');
    $f['description'] = trim($_POST['description'] ?? '');
    $f['price']       = trim($_POST['price'] ?? '');
    $f['stock']       = trim($_POST['stock'] ?? '');

    if (!csrf_check()) $errors[] = 'Invalid request.';
    if ($f['name'] === '' || strlen($f['name']) > 120) $errors[] = 'Name: required, max 120 characters.';
    if ($f['category'] === '' || strlen($f['category']) > 50) $errors[] = 'Category: required, max 50 characters.';

    $price = filter_var($f['price'], FILTER_VALIDATE_FLOAT);
    if ($price === false || $price <= 0 || $price > 1000000) $errors[] = 'Price: dapat mas mataas sa 0.';
    $stock = filter_var($f['stock'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 1000000]]);
    if ($stock === false) $errors[] = 'Stock: dapat buong numero na 0 pataas.';

    $newImage = null;
    if (!$errors) {
        $newImage = upload_image($_FILES['image'] ?? [], $errors);
    }

    if (!$errors) {
        $image = $product['image_url'] ?? null;
        if ($newImage) {
            delete_image($image);
            $image = $newImage;
        } elseif ($product && !empty($_POST['remove_image'])) {
            delete_image($image);
            $image = null;
        }

        if ($product) {
            $pdo->prepare('UPDATE products SET name=?, category=?, description=?, price=?, stock=?, image_url=? WHERE id=?')
                ->execute([$f['name'], $f['category'], $f['description'], $price, $stock, $image, $product['id']]);
            flash('Na-update ang product.');
        } else {
            $pdo->prepare('INSERT INTO products (name, category, description, price, stock, image_url) VALUES (?,?,?,?,?,?)')
                ->execute([$f['name'], $f['category'], $f['description'], $price, $stock, $image]);
            flash('Naidagdag ang product.');
        }
        redirect('products.php');
    }
}

$categories = $pdo->query('SELECT DISTINCT category FROM products ORDER BY category')->fetchAll(PDO::FETCH_COLUMN);

$base = '../';
$pageTitle = $product ? 'Edit product' : 'Add product';
require '../header.php';
?>
<h1><?= $product ? 'Edit product' : 'Add product' ?></h1>
<?php require '_nav.php'; ?>

<?php foreach ($errors as $err): ?><p class="error"><?= e($err) ?></p><?php endforeach; ?>

<div class="box">
<form method="post" enctype="multipart/form-data" class="stack">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <label>Name <input type="text" name="name" value="<?= e($f['name']) ?>" maxlength="120" required></label>
    <label>Category
        <input type="text" name="category" value="<?= e($f['category']) ?>" list="cats" maxlength="50" required>
        <datalist id="cats">
            <?php foreach ($categories as $c): ?><option value="<?= e($c) ?>"><?php endforeach; ?>
        </datalist>
    </label>
    <label>Description <input type="text" name="description" value="<?= e($f['description']) ?>"></label>
    <label>Price (₱) <input type="number" step="0.01" min="0.01" name="price" value="<?= e((string)$f['price']) ?>" required></label>
    <label>Stock <input type="number" min="0" name="stock" value="<?= e((string)$f['stock']) ?>" required></label>

    <?php if ($product && $product['image_url']): ?>
        <p>Current image:<br><img class="preview" src="../<?= e($product['image_url']) ?>" alt=""></p>
        <label class="check"><input type="checkbox" name="remove_image" value="1"> Alisin ang image</label>
    <?php endif; ?>
    <label>Image (JPG/PNG/WEBP/GIF, max 2MB) <input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></label>

    <div class="row">
        <button type="submit"><?= $product ? 'Save changes' : 'Add product' ?></button>
        <a class="btn secondary" href="products.php">Cancel</a>
    </div>
</form>
</div>
<?php require '../footer.php'; ?>
