<?php
require '../config.php';
require_role(['admin', 'staff'], '../');

$stats = [
    'products'  => (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(),
    'low_stock' => (int)$pdo->query('SELECT COUNT(*) FROM products WHERE stock <= 5')->fetchColumn(),
    'pending'   => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn(),
    'sales'     => (float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status = 'completed'")->fetchColumn(),
];
if (is_admin()) {
    $stats['users'] = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
}

$lowStock = $pdo->query('SELECT id, name, stock FROM products WHERE stock <= 5 ORDER BY stock, name LIMIT 8')->fetchAll();

$base = '../';
$pageTitle = 'Admin Dashboard';
require '../header.php';
?>
<h1>Admin Dashboard</h1>
<p>Naka-login bilang <strong><?= e($_SESSION['username']) ?></strong> <span class="badge role-<?= e($_SESSION['role']) ?>"><?= e($_SESSION['role']) ?></span></p>
<?php require '_nav.php'; ?>

<div class="stats">
    <div class="stat"><span><?= $stats['products'] ?></span>Products</div>
    <div class="stat"><span><?= $stats['low_stock'] ?></span>Low stock (≤5)</div>
    <div class="stat"><span><?= $stats['pending'] ?></span>Pending orders</div>
    <div class="stat"><span><?= money($stats['sales']) ?></span>Completed sales</div>
    <?php if (isset($stats['users'])): ?>
        <div class="stat"><span><?= $stats['users'] ?></span>Users</div>
    <?php endif; ?>
</div>

<div class="box">
    <h3>Low stock</h3>
    <?php if (!$lowStock): ?>
        <p>Okay lahat ng stock. ☕</p>
    <?php else: ?>
        <ul>
            <?php foreach ($lowStock as $p): ?>
                <li><a href="product_form.php?id=<?= (int)$p['id'] ?>"><?= e($p['name']) ?></a> — <?= (int)$p['stock'] ?> left</li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
<?php require '../footer.php'; ?>
