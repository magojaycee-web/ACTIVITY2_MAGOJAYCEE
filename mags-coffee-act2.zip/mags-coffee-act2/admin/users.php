<?php
require '../config.php';
require_role(['admin'], '../');   // User Management = admin only

$me = (int)$_SESSION['user_id'];

// UPDATE (enable/disable) and DELETE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    $s = $pdo->prepare('SELECT id, username, status FROM users WHERE id = ?');
    $s->execute([$id]);
    $target = $s->fetch();

    if (!csrf_check()) {
        flash('Invalid request.', 'error');
    } elseif (!$target) {
        flash('Hindi nahanap ang user.', 'error');
    } elseif ($id === $me) {
        flash('Hindi mo pwedeng i-disable o burahin ang sarili mong account.', 'error');
    } elseif ($action === 'toggle') {
        $new = $target['status'] === 'active' ? 'disabled' : 'active';
        $pdo->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$new, $id]);
        flash(($new === 'active' ? 'Na-enable' : 'Na-disable') . ' si ' . $target['username'] . '.');
    } elseif ($action === 'delete') {
        try {
            $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
            flash('Binura si ' . $target['username'] . '.');
        } catch (PDOException $ex) {
            // Foreign key: the user already has orders.
            flash('May order history si ' . $target['username'] . ', kaya hindi mabura. I-disable na lang.', 'error');
        }
    }
    redirect('users.php');
}

// READ (with search + role filter)
$q    = trim($_GET['q'] ?? '');
$role = $_GET['role'] ?? '';
$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(username LIKE ? OR full_name LIKE ? OR email LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%");
}
if (in_array($role, ROLES, true)) {
    $where[] = 'role = ?';
    $params[] = $role;
}
$sql = 'SELECT * FROM users' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY id';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$base = '../';
$pageTitle = 'Admin - Users';
require '../header.php';
?>
<h1>User Management</h1>
<?php require '_nav.php'; ?>

<div class="row toolbar">
    <form method="get" class="row">
        <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search username / name / email" class="search">
        <select name="role" class="auto">
            <option value="">All roles</option>
            <?php foreach (ROLES as $r): ?>
                <option value="<?= $r ?>" <?= $role === $r ? 'selected' : '' ?>><?= $r ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="secondary">Filter</button>
    </form>
    <a class="btn" href="user_form.php">+ Add user</a>
</div>

<table>
    <tr><th>Username</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last login</th><th>Actions</th></tr>
    <?php foreach ($users as $u): $isMe = (int)$u['id'] === $me; ?>
    <tr>
        <td><?= e($u['username']) ?><?= $isMe ? ' <small>(ikaw)</small>' : '' ?></td>
        <td><?= e($u['full_name']) ?></td>
        <td><?= e($u['email']) ?></td>
        <td><span class="badge role-<?= e($u['role']) ?>"><?= e($u['role']) ?></span></td>
        <td><span class="badge <?= $u['status'] === 'active' ? 'ok' : 'warn' ?>"><?= e($u['status']) ?></span></td>
        <td><small><?= e($u['last_login'] ?? '—') ?></small></td>
        <td class="actions">
            <?php if ($isMe): ?>
                <a class="btn small secondary" href="../profile.php">Profile</a>
            <?php else: ?>
                <a class="btn small" href="user_form.php?id=<?= (int)$u['id'] ?>">Edit</a>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                    <button type="submit" class="small secondary"><?= $u['status'] === 'active' ? 'Disable' : 'Enable' ?></button>
                </form>
                <form method="post" onsubmit="return confirm('Burahin si <?= e(addslashes($u['username'])) ?>?')">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                    <button type="submit" class="small danger">Delete</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$users): ?><tr><td colspan="7">Walang nahanap na user.</td></tr><?php endif; ?>
</table>
<?php require '../footer.php'; ?>
