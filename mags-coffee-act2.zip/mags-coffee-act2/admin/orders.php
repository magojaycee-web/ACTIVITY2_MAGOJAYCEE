<?php
require '../config.php';
require_role(['admin', 'staff'], '../');

$statuses = ['pending', 'processing', 'shipped', 'completed', 'cancelled'];

// UPDATE status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? '';

    if (!csrf_check() || !in_array($status, $statuses, true)) {
        flash('Invalid request.', 'error');
        redirect('orders.php');
    }

    $s = $pdo->prepare('SELECT status FROM orders WHERE id = ?');
    $s->execute([$id]);
    $old = $s->fetchColumn();

    if ($old === false) {
        flash('Hindi nahanap ang order.', 'error');
    } elseif ($old === 'cancelled' && $status !== 'cancelled') {
        flash('Hindi na mababago ang cancelled na order.', 'error');
    } elseif ($old !== $status) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $id]);

            // Cancelling an order puts the items back in stock.
            if ($status === 'cancelled') {
                $items = $pdo->prepare('SELECT product_id, qty FROM order_items WHERE order_id = ? AND product_id IS NOT NULL');
                $items->execute([$id]);
                $restock = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
                foreach ($items->fetchAll() as $it) {
                    $restock->execute([$it['qty'], $it['product_id']]);
                }
            }
            $pdo->commit();
            flash('Na-update ang order #' . $id . '.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('May error sa pag-update.', 'error');
        }
    }
    redirect('orders.php');
}

$orders = $pdo->query(
    'SELECT o.*, u.username FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.id DESC'
)->fetchAll();
$itemStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');

$base = '../';
$pageTitle = 'Admin - Orders';
require '../header.php';
?>
<h1>Orders</h1>
<?php require '_nav.php'; ?>

<?php if (!$orders): ?><p>Wala pang orders.</p><?php endif; ?>
<?php foreach ($orders as $o): ?>
<div class="box">
    <p><strong>Order #<?= (int)$o['id'] ?></strong> — <?= e($o['username']) ?> — <?= money((float)$o['total']) ?>
    <br><small><?= e($o['created_at']) ?></small></p>
    <p><?= e($o['full_name']) ?> | <?= e($o['phone']) ?><br><?= e($o['address']) ?></p>
    <ul>
        <?php
        $itemStmt->execute([$o['id']]);
        foreach ($itemStmt->fetchAll() as $it): ?>
            <li><?= e($it['product_name']) ?> × <?= (int)$it['qty'] ?></li>
        <?php endforeach; ?>
    </ul>
    <?php if ($o['status'] === 'cancelled'): ?>
        <span class="badge warn">cancelled</span>
    <?php else: ?>
    <form method="post" class="row">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
        <select name="status" class="auto">
            <?php foreach ($statuses as $st): ?>
                <option value="<?= $st ?>" <?= $o['status'] === $st ? 'selected' : '' ?>><?= $st ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="small">Update</button>
    </form>
    <?php endif; ?>
</div>
<?php endforeach; ?>
<?php require '../footer.php'; ?>
