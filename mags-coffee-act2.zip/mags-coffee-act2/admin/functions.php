<?php
// Shared helpers for the admin panel (image upload for products).

const MAX_IMAGE_BYTES = 2 * 1024 * 1024; // 2MB

// Returns the relative path ("uploads/xxxx.jpg") or null when no file was chosen.
// Adds a message to $errors when the upload is invalid.
function upload_image(array $file, array &$errors): ?string {
    $code = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($code === UPLOAD_ERR_NO_FILE) return null;
    if ($code !== UPLOAD_ERR_OK) {
        $errors[] = 'Hindi na-upload ang image. Subukan ulit.';
        return null;
    }
    if ($file['size'] > MAX_IMAGE_BYTES) {
        $errors[] = 'Masyadong malaki ang image (max 2MB).';
        return null;
    }

    // Check the real file type, not the name the browser sent.
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$mime] ?? null;
    if ($ext === null) {
        $errors[] = 'JPG, PNG, WEBP o GIF lang ang pwede.';
        return null;
    }

    $dir = __DIR__ . '/../uploads';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        $errors[] = 'Hindi magawa ang uploads folder.';
        return null;
    }

    $name = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
        $errors[] = 'Hindi ma-save ang image.';
        return null;
    }
    return 'uploads/' . $name;
}

function delete_image(?string $path): void {
    if ($path && str_starts_with($path, 'uploads/')) {
        $file = __DIR__ . '/../uploads/' . basename($path);
        if (is_file($file)) {
            unlink($file);
        }
    }
}
