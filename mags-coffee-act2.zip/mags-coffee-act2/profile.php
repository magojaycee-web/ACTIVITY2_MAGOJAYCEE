<?php
require 'config.php';
require_login();

$s = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$s->execute([$_SESSION['user_id']]);
$user = $s->fetch();

$infoErrors = $pwErrors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (!csrf_check()) {
        flash('Invalid request.', 'error');
        redirect('profile.php');
    }

    if ($action === 'info') {
        $full_name = trim($_POST['full_name'] ?? '');
        $email     = trim($_POST['email'] ?? '');

        if ($full_name === '' || strlen($full_name) > 100) $infoErrors[] = 'Ilagay ang buong pangalan.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100) $infoErrors[] = 'Maling email.';

        if (!$infoErrors) {
            $c = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id <> ?');
            $c->execute([$email, $user['id']]);
            if ($c->fetch()) $infoErrors[] = 'Gamit na ng ibang account ang email na iyon.';
        }
        if (!$infoErrors) {
            $pdo->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?')
                ->execute([$full_name, $email, $user['id']]);
            flash('Na-update ang profile.');
            redirect('profile.php');
        }
        $user['full_name'] = $full_name;
        $user['email'] = $email;
    }

    if ($action === 'password') {
        $current = $_POST['current'] ?? '';
        $new     = $_POST['new'] ?? '';
        $confirm = $_POST['confirm'] ?? '';

        if (!password_verify($current, $user['password_hash'])) $pwErrors[] = 'Mali ang current password.';
        if (strlen($new) < 8) $pwErrors[] = 'Bagong password: hindi bababa sa 8 characters.';
        if ($new !== $confirm) $pwErrors[] = 'Hindi magkapareho ang bagong password.';

        if (!$pwErrors) {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            session_regenerate_id(true);
            flash('Napalitan ang password.');
            redirect('profile.php');
        }
    }
}

$pageTitle = 'My Profile';
require 'header.php';
?>
<h1>My Profile</h1>
<p>Username: <strong><?= e($user['username']) ?></strong> · Role: <span class="badge role-<?= e($user['role']) ?>"><?= e($user['role']) ?></span></p>

<div class="two-col">
<div class="box">
    <h3>Personal info</h3>
    <?php foreach ($infoErrors as $err): ?><p class="error"><?= e($err) ?></p><?php endforeach; ?>
    <form method="post" class="stack">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="info">
        <label>Buong pangalan <input type="text" name="full_name" value="<?= e($user['full_name']) ?>" required></label>
        <label>Email <input type="email" name="email" value="<?= e($user['email']) ?>" required></label>
        <button type="submit">Save</button>
    </form>
</div>

<div class="box">
    <h3>Change password</h3>
    <?php foreach ($pwErrors as $err): ?><p class="error"><?= e($err) ?></p><?php endforeach; ?>
    <form method="post" class="stack">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="password">
        <label>Current password <input type="password" name="current" required></label>
        <label>New password <input type="password" name="new" required></label>
        <label>Confirm new password <input type="password" name="confirm" required></label>
        <button type="submit">Change password</button>
    </form>
</div>
</div>
<?php require 'footer.php'; ?>
