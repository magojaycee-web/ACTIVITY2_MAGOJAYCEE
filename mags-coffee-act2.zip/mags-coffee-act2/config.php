<?php
// Palitan ang database credentials dito.
const DB_HOST = 'localhost';
const DB_NAME = 'mags_coffee';
const DB_USER = 'root';
const DB_PASS = '';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    exit('Database connection failed.');
}

/* ---------- General helpers ---------- */

function e(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function money(float $n): string {
    return '₱' . number_format($n, 2);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_check(): bool {
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

function flash(string $msg, string $type = 'success'): void {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

/* ---------- Access control ---------- */

const ROLES    = ['admin', 'staff', 'customer'];
const STATUSES = ['active', 'disabled'];

function logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function has_role(string ...$roles): bool {
    return logged_in() && in_array($_SESSION['role'] ?? '', $roles, true);
}

function is_admin(): bool {
    return has_role('admin');
}

// Admin Panel access: admin and staff
function is_staff(): bool {
    return has_role('admin', 'staff');
}

function forbidden(string $base = ''): never {
    http_response_code(403);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>403 Forbidden</title>
<link rel="stylesheet" href="<?= e($base) ?>style.css">
</head>
<body class="center">
<div class="card">
    <h1>403 — Bawal ang access</h1>
    <p>Wala kang permission para buksan ang page na ito.</p>
    <p><a href="<?= e($base) ?>index.php">← Bumalik sa Menu</a></p>
</div>
</body>
</html>
    <?php
    exit;
}

function require_login(string $base = ''): void {
    if (!logged_in()) {
        flash('Mag-login muna.', 'error');
        redirect($base . 'login.php');
    }
}

// Usage: require_role(['admin','staff'], '../');
function require_role(array $roles, string $base = ''): void {
    require_login($base);
    if (!has_role(...$roles)) {
        forbidden($base);
    }
}

// Re-check the logged-in user on EVERY request, so a deleted user, a disabled
// account or a changed role takes effect immediately (not only at next login).
if (logged_in()) {
    $chk = $pdo->prepare('SELECT username, role, status FROM users WHERE id = ?');
    $chk->execute([$_SESSION['user_id']]);
    $me = $chk->fetch();

    if (!$me || $me['status'] !== 'active') {
        unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['role']);
        session_regenerate_id(true);
        flash($me ? 'Naka-disable ang account mo.' : 'Wala na ang account mo.', 'error');
    } else {
        $_SESSION['username'] = $me['username'];
        $_SESSION['role']     = $me['role'];
    }
}
