# MAGS COFFEE — Activity #2 (Final Term)

Access Control, User Management and CRUD, applied to the Act 1 MAGS COFFEE website.
PHP 8.1+ · MySQL/MariaDB · PDO

## Setup (XAMPP)
1. Copy this folder to `htdocs/mags-coffee-act2`.
2. phpMyAdmin → import **`database.sql`** (fresh install).
   Already imported Act 1? Import **`upgrade.sql`** instead — it keeps your data.
3. Check the DB credentials at the top of `config.php`.
4. Open `http://localhost/mags-coffee-act2/`.

## Demo accounts
| Role     | Username   | Password      |
|----------|------------|---------------|
| admin    | `admin`    | `admin123`    |
| staff    | `staff`    | `staff123`    |
| customer | `customer` | `customer123` |

Change these passwords before using the site for real.

## 1. Access Control (role-based)
| Page / action                         | Guest | Customer | Staff | Admin |
|---------------------------------------|:-----:|:--------:|:-----:|:-----:|
| Browse menu, cart                     |  ✔   |    ✔    |  ✔   |  ✔   |
| Checkout, My Orders, Profile          |       |    ✔    |  ✔   |  ✔   |
| Admin dashboard, Products CRUD, Orders|       |          |  ✔   |  ✔   |
| User Management                       |       |          |       |  ✔   |

- `require_role([...])` in `config.php` guards every protected page. Not logged in → redirected to login; wrong role → **403**.
- The user is re-checked from the database on **every request**: a disabled, deleted or re-roled account takes effect immediately.
- Public registration always creates a `customer`; only an admin can assign roles.
- Also: password hashing, CSRF tokens on every form, prepared statements, output escaping, session ID regeneration, HttpOnly/SameSite cookies, disabled-account login block.

## 2. User Management (admin only, `admin/users.php`)
Create, list (search + role filter), edit (name, email, role, status), reset password, enable/disable, delete.
- Admin can't delete/disable their own account.
- A user with order history can't be deleted (disable instead).
- Everyone can edit their own info and change their password at `profile.php`.

## 3. CRUD
- **Products** (`admin/products.php`, `admin/product_form.php`): Create, Read (search + category filter), Update, Delete, with image upload (type + size validated, stored in `uploads/`).
- **Users**: see above.
- **Orders** (`admin/orders.php`): Read and Update status. Cancelling an order returns the items to stock.

## Submit to GitHub
```
git init
git add .
git commit -m "Activity 2: access control, user management, CRUD"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo>.git
git push -u origin main
```
