<?php
require 'config.php';

if (logged_in()) {
    redirect('index.php');
}

$errors = [];
$username = $full_name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username  = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm'] ?? '';

    if (!csrf_check()) $errors[] = 'Invalid request.';
    if (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $username)) $errors[] = 'Username: 3-30 characters (letters, numbers, underscore).';
    if ($full_name === '' || strlen($full_name) > 100) $errors[] = 'Ilagay ang buong pangalan (max 100 characters).';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100) $errors[] = 'Maling email.';
    if (strlen($password) < 8) $errors[] = 'Password: hindi bababa sa 8 characters.';
    if ($password !== $confirm) $errors[] = 'Hindi magkapareho ang password.';

    if (!$errors) {
        $s = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $s->execute([$username, $email]);
        if ($s->fetch()) $errors[] = 'Gamit na ang username o email.';
    }

    if (!$errors) {
        // Public registration ALWAYS creates a "customer" — roles can only be given by an admin.
        $s = $pdo->prepare("INSERT INTO users (username, full_name, email, password_hash, role, status) VALUES (?,?,?,?, 'customer', 'active')");
        $s->execute([$username, $full_name, $email, password_hash($password, PASSWORD_DEFAULT)]);
        flash('Registered na! Pwede ka nang mag-login.');
        redirect('login.php');
    }
}

$pageTitle = 'Register';
require 'header.php';
?>
<div class="card narrow">
    <h1>Register</h1>
    <?php foreach ($errors as $err): ?><p class="error"><?= e($err) ?></p><?php endforeach; ?>
    <form method="post" class="stack">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <label>Username <input type="text" name="username" value="<?= e($username) ?>" required></label>
        <label>Buong pangalan <input type="text" name="full_name" value="<?= e($full_name) ?>" required></label>
        <label>Email <input type="email" name="email" value="<?= e($email) ?>" required></label>
        <label>Password <input type="password" name="password" required></label>
        <label>Confirm password <input type="password" name="confirm" required></label>
        <button type="submit">Register</button>
    </form>
    <p>May account ka na? <a href="login.php">Login</a></p>
</div>
<?php require 'footer.php'; ?>
