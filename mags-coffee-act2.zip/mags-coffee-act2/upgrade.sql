-- MAGS COFFEE - Activity #2 upgrade
-- Gamitin ito kung na-import mo na ang database.sql ng Act 1 (para hindi mabura ang data mo).
USE mags_coffee;

ALTER TABLE users
    ADD COLUMN full_name VARCHAR(100) NOT NULL DEFAULT '' AFTER username,
    MODIFY COLUMN role ENUM('admin','staff','customer') NOT NULL DEFAULT 'customer',
    ADD COLUMN status ENUM('active','disabled') NOT NULL DEFAULT 'active' AFTER role,
    ADD COLUMN last_login DATETIME NULL AFTER status;

UPDATE users SET full_name = username WHERE full_name = '';

-- Demo accounts: staff / staff123  |  customer / customer123
INSERT IGNORE INTO users (username, full_name, email, password_hash, role) VALUES
('staff',    'Barista Staff', 'staff@example.com',    '$2y$10$1B/3WtV.ApMAdAntinUE0Om8iZ/EajS8IngSTq52laxZG0NhZVj.u', 'staff'),
('customer', 'Demo Customer', 'customer@example.com', '$2y$10$xvkvJeOAKU82mIxoFce52u3rhQHb9tbIn7PMaxOsyw5/acpQI7XzG', 'customer');
